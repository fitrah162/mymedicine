<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class ProductsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            'generic Name' => 'fentanil',
            'form' => 'inj 0,05 mg/mL (i.m./i.v.) ',
            'restriction Formula' => '5 amp/kasus',
            'description' => 'Hanya untuk nyeri berat dan harus diberikan oleh tim medis yang dapat melakukan resusitasi.',
            'category' => '1',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'fentanil',
            'form' => 'patch 12,5 mcg/jam ',
            'restriction Formula' => '10 patch/bulan.',
            'description' => '- Untuk nyeri kronik pada
            pasien kanker yang tidak
            terkendali.
            - Tidak untuk nyeri akut.',
            'category' => '1',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'fentanil',
            'form' => 'patch 25 mcg/jam ',
            'restriction Formula' => '10 patch/bulan.',
            'description' => '- Untuk nyeri kronik pada
            pasien kanker yang tidak
            terkendali.
            - Tidak untuk nyeri akut.',
            'category' => '1',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'asam mefenamat',
            'form' => 'kaps 250 mg ',
            'restriction Formula' => '30 kaps/bulan.',
            'description' => '',
            'category' => '2',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'asam mefenamat',
            'form' => 'tab 500 mg ',
            'restriction Formula' => '30 tab/bulan.',
            'description' => '',
            'category' => '2',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'ibuprofen',
            'form' => 'tab 200 mg ',
            'restriction Formula' => '30 tab/bulan.',
            'description' => '',
            'category' => '2',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'alopurinol ',
            'form' => 'tab 100 mg* ',
            'restriction Formula' => '30 tab/bulan',
            'description' => 'Tidak diberikan pada saat nyeri akut.',
            'category' => '3',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'alopurinol ',
            'form' => 'tab 300 mg* ',
            'restriction Formula' => '30 tab/bulan',
            'description' => 'Tidak diberikan pada saat nyeri akut.',
            'category' => '3',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'kolkisin ',
            'form' => 'tab 500 mcg ',
            'restriction Formula' => '30 tab/bulan',
            'description' => 'Tidak diberikan pada saat nyeri akut.',
            'category' => '3',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        //category 4
        DB::table('products')->insert([
            'generic Name' => 'kolkisin ',
            'form' => 'tab 25 mg ',
            'restriction Formula' => '30 tab/bulan.',
            'description' => '',
            'category' => '4',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'gabapentin ',
            'form' => 'kaps 100 mg ',
            'restriction Formula' => '60 kaps/bulan.',
            'description' => 'Hanya untuk neuralgia pascaherpes
            atau nyeri neuropati diabetikum.',
            'category' => '4',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'gabapentin ',
            'form' => 'kaps 300 mg ',
            'restriction Formula' => '30 kaps/bulan.',
            'description' => 'Hanya untuk neuralgia pascaherpes
            atau nyeri neuropati diabetikum.',
            'category' => '4',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        //category 5
        DB::table('products')->insert([
            'generic Name' => 'bupivakain ',
            'form' => 'inj 0,5% ',
            'restriction Formula' => '',
            'description' => '',
            'category' => '5',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'lidokain ',
            'form' => 'inj 2%',
            'restriction Formula' => '',
            'description' => '',
            'category' => '5',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'lidokain ',
            'form' => 'spray topikal 10%',
            'restriction Formula' => '',
            'description' => '',
            'category' => '5',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        //category 6
        DB::table('products')->insert([
            'generic Name' => 'ketamin ',
            'form' => 'inj 50 mg/mL (i.v.)',
            'restriction Formula' => '',
            'description' => '',
            'category' => '6',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'ketamin ',
            'form' => 'inj 100 mg/mL (i.v.)',
            'restriction Formula' => '',
            'description' => '',
            'category' => '6',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'propofol ',
            'form' => 'inj 1% ',
            'restriction Formula' => '',
            'description' => '',
            'category' => '6',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        //category 7
        DB::table('products')->insert([
            'generic Name' => 'atropin ',
            'form' => 'inj 0,25 mg/mL (i.v./s.k.) ',
            'restriction Formula' => '',
            'description' => '',
            'category' => '7',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'midazolam ',
            'form' => 'inj 1 mg/mL (i.v.) ',
            'restriction Formula' => ' Dosis rumatan:
            1 mg/jam (24
            mg/hari).
            - Dosis premedikasi:
            8 vial/kasus.',
            'description' => 'Dapat digunakan untuk premedikasi
            sebelum induksi anestesi dan
            rumatan selama anestesi umum.',
            'category' => '7',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'midazolam ',
            'form' => 'inj 5 mg/mL (i.v.) ',
            'restriction Formula' => ' Dosis rumatan:
            1 mg/jam (24
            mg/hari).
            - Dosis premedikasi:
            8 vial/kasus.',
            'description' => 'Dapat digunakan untuk premedikasi
            sebelum induksi anestesi dan
            rumatan selama anestesi umum.',
            'category' => '7',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        //category 8
        DB::table('products')->insert([
            'generic Name' => 'deksametason ',
            'form' => 'inj 5 mg/mL ',
            'restriction Formula' => '20 mg/hari.',
            'description' => '',
            'category' => '8',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'difenhidramin ',
            'form' => 'inj 10 mg/mL (i.v./i.m.)  ',
            'restriction Formula' => '30 mg/hari.',
            'description' => '',
            'category' => '8',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'epinefrin (adrenalin) ',
            'form' => 'inj 1 mg/mL  ',
            'restriction Formula' => '',
            'description' => '',
            'category' => '8',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        //category 9
        DB::table('products')->insert([
            'generic Name' => 'atropin ',
            'form' => 'tab 0,5 mg  ',
            'restriction Formula' => '',
            'description' => '',
            'category' => '9',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'atropin ',
            'form' => 'inj 0,25 mg/mL (i.v.)  ',
            'restriction Formula' => '',
            'description' => '',
            'category' => '9',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'efedrin ',
            'form' => 'inj 50 mg/mL  ',
            'restriction Formula' => '',
            'description' => '',
            'category' => '9',
            'faskes TK1' => '0',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        //category 10
        DB::table('products')->insert([
            'generic Name' => 'fenitoin ',
            'form' => 'kaps 30 mg*  ',
            'restriction Formula' => '90 kaps/bulan.',
            'description' => '',
            'category' => '10',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'fenitoin ',
            'form' => 'kaps 100 mg*  ',
            'restriction Formula' => '120 kaps/bulan.',
            'description' => '',
            'category' => '10',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);
        DB::table('products')->insert([
            'generic Name' => 'fenitoin ',
            'form' => 'inj 50 mg/mL  ',
            'restriction Formula' => 'Untuk status
            epileptikus, dapat
            diberikan hingga
            dosis 15 - 30
            mg/kgBB di Faskes
            Tk. 2 dan 3.',
            'description' => 'Dapat digunakan untuk status
            konvulsivus',
            'category' => '10',
            'faskes TK1' => '1',
            'faskes TK2' => '1',
            'faskes TK3' => '1'
        ]);

        
        
    }
}
